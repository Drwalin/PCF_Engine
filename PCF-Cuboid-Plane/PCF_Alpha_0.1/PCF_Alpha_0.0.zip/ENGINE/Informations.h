


/*  Lista modeli:
    
    0 - czlowiek
    1 - kostka
    2 - kulka
    3 - beczka prosta wysoka ( jak w hl 2 )
    4 - beczka prosta szeroka ( jak w hl 2 )
    5 - drzwi

*/


#define HUMANMODEL 0
#define CUBEMODEL 1
#define SPHEREMODEL 2
#define BARRELHIGHMODEL 3
#define BARRELWEIDMODEL 4
#define DOORMODEL 5









