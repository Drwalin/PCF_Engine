

/*
class NameLine256 { public: char name[256];  };
class NameLine128 { public: char name[128];  };
class NameLine64  { public: char name[64];   };
class NameLine32  { public: char name[32];   };

class Vertex      { public: FLOATING_VALUES_TYPE vertex[3] };
*/

#include"TextureClass.h"

#include"ModelsClass.h"

#include"ObjectAliveClass.h"        // tylko prostopad�o�ciany
#include"ObjectPhysicalClass.h"     // tylko prostopad�o�ciany
#include"PhysicTriangleClass.h"     // tylko prostopad�o�ciany


#include"ColliderClass.h"

#include"MapClass.h"






