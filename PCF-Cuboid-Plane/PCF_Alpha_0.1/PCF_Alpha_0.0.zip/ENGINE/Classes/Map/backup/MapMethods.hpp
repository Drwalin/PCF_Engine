

/*
    UWAGA!!!
    �cie�ki do plik�w nale�y podawa� zawsze od lokacji pliku .exe ( pliku gry )

*/


#include"Map\MapColliderOperations.hpp"
#include"Map\MapLoad.hpp"
#include"Map\MapDraw.hpp"



void Map::ClearColliderAlive()
{
    unsigned int xtrg=0,ytrg=0,ztrg=0;
    for( xtrg = 0; xtrg < NUMBERTRIGGERALIVE; xtrg++ ){
    for( ytrg = 0; ytrg < NUMBERTRIGGERALIVE; ytrg++ ){
    for( ztrg = 0; ztrg < NUMBERTRIGGERALIVE; ztrg++ ){
        collideralive[xtrg][ytrg][ztrg].id.resize(0);
    }}}
}
void Map::ClearColliderPhysic()
{
    unsigned int xtrg=0,ytrg=0,ztrg=0;
    for( xtrg = 0; xtrg < NUMBERTRIGGERPHYSICAL; xtrg++ ){
    for( ytrg = 0; ytrg < NUMBERTRIGGERPHYSICAL; ytrg++ ){
    for( ztrg = 0; ztrg < NUMBERTRIGGERPHYSICAL; ztrg++ ){
        colliderphysic[xtrg][ytrg][ztrg].id.resize(0);
    }}}
}
void Map::ClearColliderTriangle()
{
    unsigned int xtrg=0,ytrg=0,ztrg=0;
    for( xtrg = 0; xtrg < NUMBERTRIGGERTRIANGLE; xtrg++ ){
    for( ytrg = 0; ytrg < NUMBERTRIGGERTRIANGLE; ytrg++ ){
    for( ztrg = 0; ztrg < NUMBERTRIGGERTRIANGLE; ztrg++ ){
        collidertriangle[xtrg][ytrg][ztrg].id.resize(0);
    }}}
}

void Map::UpdateColliderAlive()
{
    ClearColliderAlive();
    unsigned int xtrg=0,ytrg=0,ztrg=0,i=0;
    for( i = 0; i < objectphys.size() ; i++ )     //za�adowanie tr�jk�t�w do collider triggerow
    {
        for( xtrg = float(int(float(object[i].GetMinX()/SIZETRIGGERALIVE)))*SIZETRIGGERALIVE; xtrg < (object[i].GetMaxX() + ( SIZETRIGGERALIVE - (object[i].GetMaxX() - float(int(object[i].GetMaxX()/SIZETRIGGERALIVE)%2)) )); xtrg += SIZETRIGGERALIVE ){
            if( (in(xtrg)/SIZETRIGGERALIVE) >= NUMBERTRIGGERALIVE || (int)xtrg < 0 ) continue;
        for( ytrg = float(int(float(object[i].GetMinY()/SIZETRIGGERALIVE)))*SIZETRIGGERALIVE; ytrg < (object[i].GetMaxY() + ( SIZETRIGGERALIVE - (object[i].GetMaxY() - float(int(object[i].GetMaxY()/SIZETRIGGERALIVE)%2)) )); ytrg += SIZETRIGGERALIVE ){
            if( (in(xtrg)/SIZETRIGGERALIVE) >= NUMBERTRIGGERALIVE || (int)xtrg < 0 ) continue;
        for( ztrg = float(int(float(object[i].GetMinZ()/SIZETRIGGERALIVE)))*SIZETRIGGERALIVE; ztrg < (object[i].GetMaxZ() + ( SIZETRIGGERALIVE - (object[i].GetMaxZ() - float(int(object[i].GetMaxZ()/SIZETRIGGERALIVE)%2)) )); ztrg += SIZETRIGGERALIVE ){
            if( (in(xtrg)/SIZETRIGGERALIVE) >= NUMBERTRIGGERALIVE || (int)xtrg < 0 ) continue;
            
            collidertriangle[int(xtrg/SIZETRIGGERALIVE)][int(ytrg/SIZETRIGGERALIVE)][int(ztrg/SIZETRIGGERALIVE)].id.resize(
                collidertriangle[int(xtrg/SIZETRIGGERALIVE)][int(ytrg/SIZETRIGGERALIVE)][int(ztrg/SIZETRIGGERALIVE)].id.size()+1 );
            collidertriangle[int(xtrg/SIZETRIGGERALIVE)][int(ytrg/SIZETRIGGERALIVE)][int(ztrg/SIZETRIGGERALIVE)].id[
                collidertriangle[int(xtrg/SIZETRIGGERALIVE)][int(ytrg/SIZETRIGGERALIVE)][int(ztrg/SIZETRIGGERALIVE)].id.size()-1 ] = i+1;
                
        }}}
    }
}
void Map::UpdateColliderPhysic()
{
    ClearColliderPhysic();
    unsigned int xtrg=0,ytrg=0,ztrg=0,i=0;
    for( i = 0; i < objectphys.size() ; i++ )     //za�adowanie tr�jk�t�w do collider triggerow
    {
        for( xtrg = float(int(float(objectphys[i].GetMinX()/SIZETRIGGERPHYSICAL)))*SIZETRIGGERPHYSICAL; xtrg < (objectphys[i].GetMaxX() + ( SIZETRIGGERPHYSICAL - (objectphys[i].GetMaxX() - float(int(objectphys[i].GetMaxX()/SIZETRIGGERPHYSICAL)%2)) )); xtrg += SIZETRIGGERPHYSICAL ){
            if( (in(xtrg)/SIZETRIGGERPHYSICAL) >= NUMBERTRIGGERPHYSICAL || (int)xtrg < 0 ) continue;
        for( ytrg = float(int(float(objectphys[i].GetMinY()/SIZETRIGGERPHYSICAL)))*SIZETRIGGERPHYSICAL; ytrg < (objectphys[i].GetMaxY() + ( SIZETRIGGERPHYSICAL - (objectphys[i].GetMaxY() - float(int(objectphys[i].GetMaxY()/SIZETRIGGERPHYSICAL)%2)) )); ytrg += SIZETRIGGERPHYSICAL ){
            if( (in(xtrg)/SIZETRIGGERPHYSICAL) >= NUMBERTRIGGERPHYSICAL || (int)xtrg < 0 ) continue;
        for( ztrg = float(int(float(objectphys[i].GetMinZ()/SIZETRIGGERPHYSICAL)))*SIZETRIGGERPHYSICAL; ztrg < (objectphys[i].GetMaxZ() + ( SIZETRIGGERPHYSICAL - (objectphys[i].GetMaxZ() - float(int(objectphys[i].GetMaxZ()/SIZETRIGGERPHYSICAL)%2)) )); ztrg += SIZETRIGGERPHYSICAL ){
            if( (in(xtrg)/SIZETRIGGERPHYSICAL) >= NUMBERTRIGGERPHYSICAL || (int)xtrg < 0 ) continue;
            
            collidertriangle[int(xtrg/SIZETRIGGERPHYSICAL)][int(ytrg/SIZETRIGGERPHYSICAL)][int(ztrg/SIZETRIGGERPHYSICAL)].id.resize(
                collidertriangle[int(xtrg/SIZETRIGGERPHYSICAL)][int(ytrg/SIZETRIGGERPHYSICAL)][int(ztrg/SIZETRIGGERPHYSICAL)].id.size()+1 );
            collidertriangle[int(xtrg/SIZETRIGGERPHYSICAL)][int(ytrg/SIZETRIGGERPHYSICAL)][int(ztrg/SIZETRIGGERPHYSICAL)].id[
                collidertriangle[int(xtrg/SIZETRIGGERPHYSICAL)][int(ytrg/SIZETRIGGERPHYSICAL)][int(ztrg/SIZETRIGGERPHYSICAL)].id.size()-1 ] = i+1;
                
        }}}
    }
}
void Map::UpdateColliderTriangle()
{
    ClearColliderTriangle();
    unsigned int xtrg=0,ytrg=0,ztrg=0,i=0;
    for( i = 0; i < triangle.size() ; i++ )     //za�adowanie tr�jk�t�w do collider triggerow
    {
        for( xtrg = float(int(float(triangle[i].GetMinX()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; xtrg < (triangle[i].GetMaxX() + ( SIZETRIGGERTRIANGLE - (triangle[i].GetMaxX() - float(int(triangle[i].GetMaxX()/SIZETRIGGERTRIANGLE)%2)) )); xtrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
        for( ytrg = float(int(float(triangle[i].GetMinY()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; ytrg < (triangle[i].GetMaxY() + ( SIZETRIGGERTRIANGLE - (triangle[i].GetMaxY() - float(int(triangle[i].GetMaxY()/SIZETRIGGERTRIANGLE)%2)) )); ytrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
        for( ztrg = float(int(float(triangle[i].GetMinZ()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; ztrg < (triangle[i].GetMaxZ() + ( SIZETRIGGERTRIANGLE - (triangle[i].GetMaxZ() - float(int(triangle[i].GetMaxZ()/SIZETRIGGERTRIANGLE)%2)) )); ztrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
            
            collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.resize(
                collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.size()+1 );
            collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id[
                collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.size()-1 ] = i+1;
                
        }}}
    }
}







int Map::LoadInit( NameLine128 name )
{
    Nameline64 argument;
    FLOATING_VALUES_TYPE argumentfloat;
    
    fstream file;
    file.open( name.name, ios::in );
    if( !file.good() )
    {
        return LOADING_FILE_FOULT;              // b��d przy wczyywaniu pliku textury
    }
    {
        file >> argument.name[0];
        switch( argument.name[0] )
        {
        case FULL_WORDS_ARGUMENTS_1_0:
            {
                    while( 1 )
                    {
                        argument.name[0] = 0;
                        file >> argument.name;
                        if(      strcmp( argument.name, "texture" ) )               // za�aduje i zainicjuj texture
                        {
                            file.getline( argument.name, 128 );
                            textures.resize( textures.size()+1 );
                            textures[textures.size()-1].LoadInit( argument.name );
                            continue;
                        }
                        else if( strcmp( argument.name, "model" ) )                 // za�aduj i zainicjuj model
                        {
                            file.getline( argument.name, 128 );
                            models.resize( models.size()+1 );
                            models[models.size()-1].LoadInit( argument.name );
                            continue;
                        }
                        else if( strcmp( argument.name, "object" ) )                // wybierz obiekt
                        {
                            argument.name[0] = 0;
                            file >> argument.name;
                            if(      strcmp( argument.name, "alive" ) )             // za�aduj obiekt �ywy ( bez kolizji i fizyki obrot�w )
                            {
                                object.resize( object.size()+1 );
                                file >> argument.name;
                                file >> object[object.size()-1].pos.vertex[0];
                                file >> object[object.size()-1].pos.vertex[1];
                                file >> object[object.size()-1].pos.vertex[2];
                                file >> argument.name;
                                file >> object[object.size()-1].width;
                                file >> argument.name;
                                file >> object[object.size()-1].heightlegs;
                                file >> argument.name;
                                file >> object[object.size()-1].heightches;
                                file >> argument.name;
                                file >> object[object.size()-1].heighhead;
                                file >> argument.name;
                                file >> object[object.size()-1].mass;
                                file >> argument.name;
                                file >> object[object.size()-1].type;
                                file >> argument.name;
                                file >> object[object.size()-1].id;
                                file >> argument.name;
                                file >> object[object.size()-1].id_graphicmodel;
                                file >> argument.name;
                                file >> object[object.size()-1].name;
                            }
                            else if( strcmp( argument.name, "physic" ) )            // za�aduj obiekt martwy ( z kolizj� i fizyk� obrot�w )
                            {
                            }
                            else
                            {
                                return INVALID_ARGUMENT;
                            }
                        }
                        else if( strcmp( argument.name, "triangle" ) )              // wczytanie i zainiciowanie tr�jk�ta fizycznego ( bez zainstalowania w colliderach 0
                        {
                            triangle.resize( triangle.size()+1 );
                            file >> argument.name;
                            file >> triangle[triangle.size()-1].tri[0].vertex[0];
                            file >> triangle[triangle.size()-1].tri[0].vertex[1];
                            file >> triangle[triangle.size()-1].tri[0].vertex[2];
                            file >> argument.name;
                            file >> triangle[triangle.size()-1].tri[1].vertex[0];
                            file >> triangle[triangle.size()-1].tri[1].vertex[1];
                            file >> triangle[triangle.size()-1].tri[1].vertex[2];
                            file >> argument.name;
                            file >> triangle[triangle.size()-1].tri[2].vertex[0];
                            file >> triangle[triangle.size()-1].tri[2].vertex[1];
                            file >> triangle[triangle.size()-1].tri[2].vertex[2];
                            file >> argument.name;
                            file >> triangle[triangle.size()-1].texture;            // je�li 0 to nie rysowa�
                            
                            file >> triangle[triangle.size()-1].CalculateNormal();  // obliczenie normalnej p�aszczyzny
                            file >> triangle[triangle.size()-1].CalculateDet();     // obliczenie wska�nika przesuni�cia tr�jk�ta w przestrzeni
                        }
                        else if( strcmp( argument.name, "stop" ) )                  // zako�czenie �adowania i inicjowania modeli, textu, obiekt�w, tr�jk�t�w fozcznych i przej�cie do iniciowania obiekt�w w collider triggerach
                        {
                            goto INIT_COLLIDER_TRIGGERS;
                        }
                        else if( strcmp( argument.name, "//" ) )            // komentarz jednoliniowy o maksymalnej d�ugo�ci 126 znak�w (wliczaj�c spacje i znaki specjalne pr�cz znaku przej�cia do nowej linii
                        {
                            file.getline( argument.name, 128 );
                        }
                        else if( strcmp( argument.name, "/*" ) )            // komentarz wieloliniowy
                        {
                            while( !strcmp( argument.name, "*/" )
                            {
                                file >> argument.name;
                            }
                        }
                        
                        
                        
                    }
            }
            break;
        case BINARY_ARGUMENTS_1_0:
            {
            }
            break;
        default:
            return INVALID_ARGUMENT;
        }
    }
    
    INIT_COLLIDER_TRIGGERS:
        
        
        UpdateColliderAlive();
        UpdateColliderPhysic();
        UpdateColliderTriangle();
        
        
        
    /*
    unsigned int xtrg=0,ytrg=0,ztrg=0,i=0;
    for( i = 0; i < triangle.size() ; i++ )     //za�adowanie tr�jk�t�w do collider triggerow
    {
        for( xtrg = float(int(float(triangle[i].GetMinX()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; xtrg < (triangle[i].GetMaxX() + ( NUMBERTRIGGERTRIANGLE - (triangle[i].GetMaxX() - float(int(triangle[i].GetMaxX()/SIZETRIGGERTRIANGLE)%2)) )); xtrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
        for( ytrg = float(int(float(triangle[i].GetMinY()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; ytrg < (triangle[i].GetMaxY() + ( NUMBERTRIGGERTRIANGLE - (triangle[i].GetMaxY() - float(int(triangle[i].GetMaxY()/SIZETRIGGERTRIANGLE)%2)) )); ytrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
        for( ztrg = float(int(float(triangle[i].GetMinZ()/SIZETRIGGERTRIANGLE)))*SIZETRIGGERTRIANGLE; ztrg < (triangle[i].GetMaxZ() + ( NUMBERTRIGGERTRIANGLE - (triangle[i].GetMaxZ() - float(int(triangle[i].GetMaxZ()/SIZETRIGGERTRIANGLE)%2)) )); ztrg += SIZETRIGGERTRIANGLE ){
            if( (in(xtrg)/SIZETRIGGERTRIANGLE) >= NUMBERTRIGGERTRIANGLE || (int)xtrg < 0 ) continue;
            
            collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.resize(
                collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.size()+1 );
            collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id[
                collidertriangle[int(xtrg/SIZETRIGGERTRIANGLE)][int(ytrg/SIZETRIGGERTRIANGLE)][int(ztrg/SIZETRIGGERTRIANGLE)].id.size()-1 ] = i+1;
                
        }}}
    }*/
    
    
    
    //return UNKNOWN_ERROR;
    return NORMAL_FILE_LOADED;
}
