





class ColliderCell
{
public:
    vector < unsigned int > id;
    
    ColliderCell();     // +
};




