ColliderCell::ColliderCell()
{
    id.resize( 0 );
}
