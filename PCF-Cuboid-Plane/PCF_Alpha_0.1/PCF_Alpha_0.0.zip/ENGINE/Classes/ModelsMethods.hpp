












Models::Models()
{
    vertices.resize( 0 );
    id_texture.resize( 0 );
    textures.resize( 0 );
    
    type = 0; // 0 - nie rysuj, 1-punkty, 2-linie, 3-tr�jk�ty, 4-czworok�ty ...
    
    name.name[0] = 0;
}
