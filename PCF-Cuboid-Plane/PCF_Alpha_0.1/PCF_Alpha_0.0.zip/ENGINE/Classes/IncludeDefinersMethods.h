






#include"TextureMethods.hpp"

#include"ModelsMethods.hpp"

#include"ObjectAliveMethods.hpp"        // tylko prostopad�o�ciany
#include"ObjectPhysicalMethods.hpp"     // tylko prostopad�o�ciany
#include"PhysicTriangleMethods.hpp"     // tylko prostopad�o�ciany

#include"ColliderMethods.hpp"

#include"MapMethods.hpp"
