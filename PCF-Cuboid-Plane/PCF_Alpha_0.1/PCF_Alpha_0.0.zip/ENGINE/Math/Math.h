

/*

    // iloczyn wektorowy:
void CalculateVectorMulv( Vertex * vector1, Vertex * vector2, Vertex * output )
{
	output->vertex[0] = vector1->vertex[1]*vector2->vertex[2] - vector1->vertex[2]*vector2->vertex[1];
	output->vertex[1] = vector1->vertex[2]*vector2->vertex[0] - vector1->vertex[0]*vector2->vertex[2];
	output->vertex[2] = vector1->vertex[0]*vector2->vertex[1] - vector1->vertex[1]*vector2->vertex[0];
}

Vertex CalculateVectorMul( Vertex vector1, Vertex vector2 )
{
    Vertex output;
	output.vertex[0] = vector1.vertex[1]*vector2.vertex[2] - vector1.vertex[2]*vector2.vertex[1];
	output.vertex[1] = vector1.vertex[2]*vector2.vertex[0] - vector1.vertex[0]*vector2.vertex[2];
	output.vertex[2] = vector1.vertex[0]*vector2.vertex[1] - vector1.vertex[1]*vector2.vertex[0];
	
	return output;
}

*/



