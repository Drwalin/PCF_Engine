

//vector< vector< EngineColliderTrigger > > trigger;

Map map;

//vector< EngineGraphicModel > environmentmodel;
//vector< EngineEnvironmentModel > environment;   //np. trawa, rosliny... (obiekty bez fizyki)


//vector< EngineHumanoidGraphicModel > humanoid;
//vector< EngineCubeGraphicModel > cubes;





/*
vector < CharName > texturefiles;
vector < BITMAPINFOHEADER > bitmapInfoHeader;
vector < unsigned char * > bitmapData;
vector < unsigned int > texture;
*/






